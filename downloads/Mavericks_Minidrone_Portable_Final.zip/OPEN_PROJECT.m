% =========================================================================
% MAVERICKS MINIDRONE INDIA 2026 - ONE-CLICK PROJECT STARTER
% =========================================================================
% Usage:
%   1. Extract the ZIP archive to any folder on your computer.
%   2. In MATLAB, navigate to that extracted folder.
%   3. Type "OPEN_PROJECT" in the MATLAB Command Window.
%
% This script automatically extracts the project, sets the path, loads your
% custom track, opens the main Simulink model, and opens the Track Builder.
% =========================================================================

bundle = fileparts(mfilename('fullpath'));
destination = fullfile(bundle, 'Mavericks_Project');

fprintf('=== MAVERICKS MINIDRONE INDIA 2026 ===\n');
fprintf('Initializing project environment...\n');

if ~isfolder(destination)
    fprintf('Extracting project archive (first-time setup)...\n');
    p = matlab.project.extractProject(fullfile(bundle, 'Mavericks_MDCIndia_2026.mlproj'), destination);
else
    fprintf('Opening existing project folder...\n');
    p = openProject(destination);
end

cd(char(p.RootFolder));

% Ensure the user custom track is copied into the project root if needed
customTrack = fullfile(bundle, 'TEST_TRACKS', 'my_custom_track.mat');
projectTrack = fullfile(char(p.RootFolder), 'initData.mat');
if isfile(customTrack) && ~isfile(projectTrack)
    copyfile(customTrack, projectTrack);
    fprintf('Custom track installed to project root.\n');
end

% Clear runtime function caches
clear mdc_guidance mdc_vision mdc_route_select mdc_finish_marker mdc_partial_marker ...
      mdc_prepare_simulation mdc_run_custom mdc_manual_check mdc_check_submission mdc_visible_progress;

% Open the main Simulink model and Competition Track Builder
fprintf('Opening main Simulink model...\n');
open_system('PX4MultiCopterPerceptionAndControl');

fprintf('Opening Competition Track Builder...\n');
if exist('openTrackBuilder', 'file') == 2
    openTrackBuilder;
elseif exist('CompetitionTrackBuilder', 'file') == 2 || exist('CompetitionTrackBuilder', 'file') == 6
    CompetitionTrackBuilder;
end

fprintf('\n====================================================================\n');
fprintf('PROJECT LOADED AND READY!\n');
fprintf('To run the drone simulation on your track, enter in the Command Window:\n');
fprintf('    mdc_run_custom(120)\n');
fprintf('Or click the "Run" button on the Simulink toolbar.\n');
fprintf('====================================================================\n\n');
